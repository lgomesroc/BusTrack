﻿namespace BusTrack.BusTrack.API.DTOAPI
{
    public class DriverDTOAPI
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? LicenseNumber { get; set; }
    }
}

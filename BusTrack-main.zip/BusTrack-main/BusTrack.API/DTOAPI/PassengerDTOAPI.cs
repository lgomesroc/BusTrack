﻿namespace BusTrack.BusTrack.API.DTOAPI
{
    public class PassengerDTOAPI
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public int Age { get; set; }
    }
}

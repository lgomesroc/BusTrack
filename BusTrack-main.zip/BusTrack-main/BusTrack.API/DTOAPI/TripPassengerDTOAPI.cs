﻿namespace BusTrack.BusTrack.API.DTOAPI
{
    public class TripPassengerDTOAPI
    {
        public int Id { get; set; }
        public int TripId { get; set; }
        public int PassengerId { get; set; }
    }
}

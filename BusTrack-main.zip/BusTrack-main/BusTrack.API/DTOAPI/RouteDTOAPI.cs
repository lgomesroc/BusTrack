﻿namespace BusTrack.BusTrack.API.DTOAPI
{
    public class RouteDTOAPI
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Origin { get; set; }
        public string? Destination { get; set; }
        public int Distance { get; set; }



    }
}

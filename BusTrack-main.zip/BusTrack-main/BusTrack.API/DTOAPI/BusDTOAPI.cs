﻿namespace BusTrack.BusTrack.API.DTOAPI
{
    public class BusDTOAPI
    {
        public string? Id { get; set; }
        public string? LicensePlate { get; set; }
        public string? Model { get; set; }
        public int Capacity { get; set; }
    }
}

﻿namespace BusTrack.BusTrack.API.ModelsAPI
{
    public class DriverModelAPI
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? LicenseNumber { get; set; }
    }
}

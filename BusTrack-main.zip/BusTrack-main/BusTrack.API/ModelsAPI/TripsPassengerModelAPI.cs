﻿namespace BusTrack.BusTrack.API.ModelsAPI
{
    public class TripsPassengerModelAPI
    {
        public string? Id { get; set; }
        public string? TripId { get; set; }
        public string? PassengerId { get; set; }
    }
}

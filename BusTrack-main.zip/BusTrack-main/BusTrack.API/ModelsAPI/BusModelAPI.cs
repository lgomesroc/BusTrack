﻿namespace BusTrack.BusTrack.API.ModelsAPI
{
    public class BusModelAPI
    {
        public int Id { get; set; }
        public string? PlateNumber { get; set; }
        public string? Model { get; set; }
        public int Capacity { get; set; }
    }
}

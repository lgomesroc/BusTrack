﻿namespace BusTrack.BusTrack.Updater
{
    public class PassengerNameUpdater
    {
        public string? Name { get; set; }
    }
}

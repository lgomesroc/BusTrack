﻿namespace BusTrack.BusTrack.Updater.Drivers
{
    public class DriverNameUpdater
    {
        public string? Name { get; set; }
    }
}

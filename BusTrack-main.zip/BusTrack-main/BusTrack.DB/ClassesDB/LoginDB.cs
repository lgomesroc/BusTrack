﻿namespace BusTrack.BusTrack.DB.ClassesDB
{
    public class LoginDB
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
    }
}
